# الوثائق التقنية لمنصة سكيلر التعليمية

## نظرة عامة على الهيكل

منصة سكيلر التعليمية مبنية باستخدام هيكل MERN (MongoDB, Express, React, Node.js) وتتكون من:

1. **الواجهة الخلفية (Backend)**: API مبني باستخدام Node.js وExpress
2. **الواجهة الأمامية (Frontend)**: تطبيق React مع واجهة مستخدم عربية
3. **قاعدة البيانات**: MongoDB لتخزين البيانات
4. **نظام تخزين الملفات**: لتخزين الفيديوهات والصور

## هيكل المجلدات

```
skiller-platform/
├── backend/             # الواجهة الخلفية
│   ├── config/          # ملفات التكوين
│   ├── controllers/     # وحدات التحكم
│   ├── middleware/      # البرمجيات الوسيطة
│   ├── models/          # نماذج قاعدة البيانات
│   ├── routes/          # مسارات API
│   ├── utils/           # أدوات مساعدة
│   └── server.js        # نقطة الدخول الرئيسية
├── frontend/            # الواجهة الأمامية
│   ├── public/          # الملفات العامة
│   └── src/             # كود المصدر
│       ├── components/  # مكونات React
│       ├── context/     # سياقات React
│       ├── pages/       # صفحات التطبيق
│       └── assets/      # الصور والأيقونات
├── uploads/             # مجلد تخزين الملفات المرفوعة
└── docs/                # الوثائق
```

## الواجهة الخلفية (Backend)

### التقنيات المستخدمة

- **Node.js**: بيئة التشغيل
- **Express**: إطار عمل الويب
- **MongoDB**: قاعدة البيانات
- **Mongoose**: مكتبة ODM للتعامل مع MongoDB
- **JWT**: للمصادقة وإدارة الجلسات
- **Multer**: لرفع الملفات
- **Bcrypt**: لتشفير كلمات المرور

### نماذج قاعدة البيانات

#### نموذج المستخدم (User)

```javascript
{
  name: String,
  email: String,
  password: String,
  role: String, // 'user', 'instructor', 'admin'
  avatar: String,
  bio: String,
  createdAt: Date,
  updatedAt: Date
}
```

#### نموذج الكورس (Course)

```javascript
{
  title: String,
  description: String,
  instructor: { type: ObjectId, ref: 'User' },
  thumbnail: String,
  price: Number,
  category: String,
  level: String, // 'beginner', 'intermediate', 'advanced'
  requirements: [String],
  whatYouWillLearn: [String],
  isPublished: Boolean,
  createdAt: Date,
  updatedAt: Date
}
```

#### نموذج الفيديو (Video)

```javascript
{
  title: String,
  description: String,
  course: { type: ObjectId, ref: 'Course' },
  videoUrl: String,
  duration: String,
  order: Number,
  isFree: Boolean,
  fileSize: Number,
  createdAt: Date,
  updatedAt: Date
}
```

#### نموذج التحليلات (Analytics)

```javascript
{
  user: { type: ObjectId, ref: 'User' },
  course: { type: ObjectId, ref: 'Course' },
  video: { type: ObjectId, ref: 'Video' },
  action: String, // 'view', 'enroll', 'complete'
  timestamp: Date
}
```

### نقاط النهاية API

#### المصادقة

- `POST /api/v1/auth/register`: تسجيل مستخدم جديد
- `POST /api/v1/auth/login`: تسجيل الدخول
- `GET /api/v1/auth/me`: الحصول على بيانات المستخدم الحالي
- `PUT /api/v1/auth/updatedetails`: تحديث بيانات المستخدم
- `PUT /api/v1/auth/updatepassword`: تحديث كلمة المرور

#### المستخدمين

- `GET /api/v1/users`: الحصول على جميع المستخدمين (للمسؤولين فقط)
- `GET /api/v1/users/:id`: الحصول على مستخدم محدد
- `POST /api/v1/users`: إنشاء مستخدم جديد (للمسؤولين فقط)
- `PUT /api/v1/users/:id`: تحديث مستخدم
- `DELETE /api/v1/users/:id`: حذف مستخدم

#### الكورسات

- `GET /api/v1/courses`: الحصول على جميع الكورسات
- `GET /api/v1/courses/:id`: الحصول على كورس محدد
- `POST /api/v1/courses`: إنشاء كورس جديد
- `PUT /api/v1/courses/:id`: تحديث كورس
- `DELETE /api/v1/courses/:id`: حذف كورس
- `GET /api/v1/courses/:id/videos`: الحصول على فيديوهات كورس محدد

#### الفيديوهات

- `GET /api/v1/videos`: الحصول على جميع الفيديوهات
- `GET /api/v1/videos/:id`: الحصول على فيديو محدد
- `POST /api/v1/courses/:courseId/videos`: إنشاء فيديو جديد
- `PUT /api/v1/videos/:id`: تحديث فيديو
- `DELETE /api/v1/videos/:id`: حذف فيديو
- `PUT /api/v1/videos/:id/upload`: رفع ملف الفيديو

#### التحليلات

- `GET /api/v1/analytics/users`: الحصول على تحليلات المستخدمين
- `GET /api/v1/analytics/courses`: الحصول على تحليلات الكورسات
- `GET /api/v1/analytics/videos`: الحصول على تحليلات الفيديوهات
- `GET /api/v1/analytics/revenue`: الحصول على تحليلات الإيرادات

### البرمجيات الوسيطة

- **auth.js**: للتحقق من المصادقة والصلاحيات
- **error.js**: لمعالجة الأخطاء
- **advancedResults.js**: للتصفية والفرز والصفحات
- **async.js**: لمعالجة الدوال غير المتزامنة

## الواجهة الأمامية (Frontend)

### التقنيات المستخدمة

- **React**: مكتبة واجهة المستخدم
- **React Router**: للتنقل بين الصفحات
- **Context API**: لإدارة حالة التطبيق
- **Axios**: لطلبات HTTP
- **Styled Components**: لتنسيق المكونات
- **Chart.js**: لعرض الرسوم البيانية
- **Formik & Yup**: للنماذج والتحقق من الصحة

### المكونات الرئيسية

#### سياقات (Contexts)

- **AuthContext**: لإدارة حالة المصادقة
- **CourseContext**: لإدارة الكورسات
- **VideoContext**: لإدارة الفيديوهات
- **AnalyticsContext**: لإدارة التحليلات

#### الصفحات الرئيسية

- **HomePage**: الصفحة الرئيسية
- **CoursesPage**: صفحة عرض الكورسات
- **CourseDetailPage**: صفحة تفاصيل الكورس
- **VideoPlayerPage**: صفحة مشغل الفيديو
- **LoginPage & RegisterPage**: صفحات المصادقة

#### صفحات المدرس

- **InstructorCoursesPage**: صفحة كورسات المدرس
- **CreateCoursePage**: صفحة إنشاء كورس جديد
- **EditCoursePage**: صفحة تعديل الكورس
- **AddVideoPage**: صفحة إضافة فيديو
- **UploadVideoPage**: صفحة رفع ملف الفيديو

#### صفحات المسؤول

- **AdminDashboardPage**: لوحة تحكم المسؤول
- **UserAnalyticsPage**: تحليلات المستخدمين
- **CourseAnalyticsPage**: تحليلات الكورسات

## إعداد البيئة

### متطلبات النظام

- Node.js (الإصدار 14 أو أحدث)
- MongoDB
- متصفح حديث

### خطوات التثبيت

1. استنساخ المشروع:
```bash
git clone https://github.com/your-username/skiller-platform.git
cd skiller-platform
```

2. تثبيت الاعتماديات:
```bash
npm install
cd backend && npm install
cd ../frontend && npm install
```

3. إعداد ملف البيئة:
```bash
# في مجلد backend، قم بإنشاء ملف .env
PORT=5000
MONGO_URI=mongodb://localhost:27017/skiller
JWT_SECRET=your_jwt_secret
NODE_ENV=development
MAX_FILE_SIZE=1024000000
UPLOAD_PATH=../uploads
```

4. تشغيل التطبيق في وضع التطوير:
```bash
# من المجلد الرئيسي
npm run dev
```

## النشر

### نشر الواجهة الخلفية

1. بناء الواجهة الخلفية:
```bash
cd backend
npm run build
```

2. نشر المجلد `dist` على خادم Node.js

### نشر الواجهة الأمامية

1. بناء الواجهة الأمامية:
```bash
cd frontend
npm run build
```

2. نشر المجلد `build` على خادم ويب ثابت

## الأمان

- تشفير كلمات المرور باستخدام bcrypt
- استخدام JWT للمصادقة
- التحقق من الصلاحيات للوصول إلى الموارد
- حماية من هجمات XSS وCSRF
- تحديد معدل الطلبات لمنع هجمات DDoS

## التوسع المستقبلي

- إضافة دعم للغات متعددة
- تكامل مع منصات الدفع
- إضافة نظام للشهادات
- تحسين نظام البحث
- إضافة منتدى للنقاش
- تطبيقات للهواتف المحمولة

## استكشاف الأخطاء وإصلاحها

### مشاكل الاتصال بقاعدة البيانات

- تأكد من تشغيل خادم MongoDB
- تحقق من صحة رابط الاتصال في ملف .env
- تأكد من وجود الصلاحيات المناسبة للوصول إلى قاعدة البيانات

### مشاكل رفع الفيديو

- تأكد من وجود مجلد uploads وأنه قابل للكتابة
- تحقق من حجم الملف (الحد الأقصى 1GB)
- تأكد من تكوين multer بشكل صحيح

### مشاكل المصادقة

- تحقق من صحة JWT_SECRET في ملف .env
- تأكد من عدم انتهاء صلاحية الرمز المميز
- تحقق من الصلاحيات المطلوبة للوصول إلى الموارد
